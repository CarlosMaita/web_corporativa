
    <!-- header -->
    <header class="header-sticky header-dark">
        <div class="container">
          <nav class="navbar navbar-expand-lg navbar-<?php echo e($color_header ?? 'light'); ?>">
            <a class="navbar-brand" href="../../index.html">
              
              
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="burger"><span></span></span></button>
  
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav align-items-center mr-auto">
                <li class="nav-item">
                  <a class="nav-link" href="/" role="button">
                    Inicio
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/nosotros" role="button">
                    Nosotros
                  </a>
                </li>
                
                <li class="nav-item">
                  <a class="nav-link" href="/productos" role="button">
                    Productos
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="/contacto" role="button">
                    Contacto
                  </a>
                </li>
              </ul>
  
              
              <a href="tel:+58-424-401-07-76" class="phone bordered">+58 424 401 0776</a><br>
            </div>
          </nav>
        </div>
      </header>
      <!-- header --><?php /**PATH D:\web_corporativa\resources\views/common/header.blade.php ENDPATH**/ ?>